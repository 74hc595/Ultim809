Layers:
u809.frontsilk.gbr    - silkscreen (top), includes board outline
u809.frontmask.gbr    - top solder mask
u809.front.gbr        - top copper
u809.back.gbr         - bottom copper
u809.backmask.gbr     - back solder mask

u809.plated-drill.cnc - Excellon drill file
u809.fab.gbr          - Fabrication drawing (informational only)

All files are positive polarity. Populated areas on solder mask files
indicate areas without solder mask.

